/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.Calculado;

import java.util.ArrayList;

/**
 *
 * @author jhamildanielrl
 */
public class Calculator {

    public static void main(String[] args) {
        String entrada = "sin(cos(9)+sen(8))+cos(3)";
        String salida=new Cos(new Sin(entrada).resultado()).resultado();
        System.out.println(salida);
            
    }
    public static double resultado(String entrada){
        Operando resulta=new Operando(entrada);
        System.out.println("INFO:Calculando:"+resulta);
       return resulta.resultado();
    }
    
}


